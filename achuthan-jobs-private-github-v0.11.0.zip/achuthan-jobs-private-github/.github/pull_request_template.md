## What changed

<!-- Explain the job/application/admin behavior affected. -->

## Security and privacy

- [ ] No passwords, tokens, wp-config, salts, applicant data or resumes committed
- [ ] Permissions, CSRF/nonces and inputs checked for changed endpoints
- [ ] Sensitive admin/file responses cannot be publicly cached

## Verification

- [ ] `bash scripts/verify.sh` passed (mocked tests)
- [ ] Tested on private WordPress staging with the actual Frisk/Elementor versions
- [ ] Plugin ZIP built and backup/rollback plan prepared
